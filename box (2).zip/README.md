the website describe dabataxi services
there are three navigation bars with dropdown menu.
there is video that tells users about our services
there is a table that shows data of users in different cities in Morocco
there is also a form made of email and password that users need to provide to submit any quiry
css animation that thanks and appreciate our customers